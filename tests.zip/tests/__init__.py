from zipline import setup, teardown  # noqa For nosetests
