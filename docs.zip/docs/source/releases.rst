=============
Release Notes
=============

.. include:: whatsnew/1.4.1.txt

.. include:: whatsnew/1.4.0.txt

.. include:: whatsnew/1.3.0.txt

.. include:: whatsnew/1.2.0.txt

.. include:: whatsnew/1.1.1.txt

.. include:: whatsnew/1.1.0.txt

.. include:: whatsnew/1.0.2.txt

.. include:: whatsnew/1.0.1.txt

.. include:: whatsnew/1.0.0.txt

.. include:: whatsnew/0.9.0.txt

.. include:: whatsnew/0.8.4.txt

.. include:: whatsnew/0.8.3.txt

.. include:: whatsnew/0.8.0.txt

.. include:: whatsnew/0.7.0.txt

.. include:: whatsnew/0.6.1.txt
